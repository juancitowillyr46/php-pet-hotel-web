<?php


namespace App\BackOffice\Security\Domain\Entities;


class TokenEntity
{
    public string $token;

    /**
     * @return string
     */
    public function getToken(): string
    {
        return $this->token;
    }

    /**
     * @param string $token
     */
    public function setToken(string $token): void
    {
        $this->token = $token;
    }



    
}