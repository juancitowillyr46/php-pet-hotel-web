<?php


namespace App\Shared\Domain\Entities;


class CommonDto
{
    public string $value;
    public string $text;
}