<?php
declare(strict_types=1);

// Database settings
$settings['db']['username'] = 'root';
$settings['db']['password'] = '';
$settings['db']['host'] = 'localhost';
$settings['db']['database'] = 'localhost';
