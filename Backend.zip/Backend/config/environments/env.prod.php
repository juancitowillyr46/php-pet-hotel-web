<?php
declare(strict_types=1);

// Database settings
$settings['db']['username'] = 'root';
$settings['db']['password'] = '';