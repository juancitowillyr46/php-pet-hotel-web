<?php


namespace App\Shared\Domain\Entities;


class CommonBooleanDto
{
    public bool $value;
    public string $text;
}